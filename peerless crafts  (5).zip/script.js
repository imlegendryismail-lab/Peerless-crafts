function addToCart(name, price){

let cart = JSON.parse(localStorage.getItem("cart")) || [];

cart.push({name, price});

localStorage.setItem("cart", JSON.stringify(cart));

// show message
let msg = document.getElementById("cartMessage");
if(msg){
msg.style.display = "block";

setTimeout(() => {
msg.style.display = "none";
}, 2000);
}
}